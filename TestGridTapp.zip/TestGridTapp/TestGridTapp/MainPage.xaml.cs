﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace TestGridTapp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            ChannelAvatarLogo.AvatarName = "Test Project";
            LabelChannelName.Text = "Test Project";
            LabelChannelCountry.Text = "United States";
        }

        void TapGestureRecognizerShowChannels_Tapped(System.Object sender, System.EventArgs e)
        {
            DisplayAlert("Tapped", "Hello", "Ok");
            // ShowChannels();
        }

        void SegmentedPayment_SelectionChanged(System.Object sender, Syncfusion.XForms.Buttons.SelectionChangedEventArgs e)
        {

        }

        void SegmentedPaymentFrequency_SelectionChanged(System.Object sender, Syncfusion.XForms.Buttons.SelectionChangedEventArgs e)
        {

        }

        void TapGestureRecognizerShowDate_Tapped(System.Object sender, System.EventArgs e)
        {
            // PickerDate.IsOpen = true;
        }

        void TapGestureRecognizerClearDate_Tapped(System.Object sender, System.EventArgs e)
        {

        }

        void ButtonCloseDatePicker_Clicked(System.Object sender, System.EventArgs e)
        {

        }

        void ButtonSelectDatePicker_Clicked(System.Object sender, System.EventArgs e)
        {

        }

        void TapGestureRecognizerShowTime_Tapped(System.Object sender, System.EventArgs e)
        {

        }

        void ButtonCloseTimePicker_Clicked(System.Object sender, System.EventArgs e)
        {

        }

        void ButtonSelectTimePicker_Clicked(System.Object sender, System.EventArgs e)
        {

        }

        void TapGestureRecognizerShowDuration_Tapped(System.Object sender, System.EventArgs e)
        {

        }

        void TapGestureRecognizerClearDuration_Tapped(System.Object sender, System.EventArgs e)
        {

        }

        void PickerDuration_SelectionChanged(System.Object sender, Syncfusion.SfPicker.XForms.SelectionChangedEventArgs e)
        {

        }

        void ButtonPickerDuration_Clicked(System.Object sender, System.EventArgs e)
        {

        }

        void TapGestureRecognizerClearTime_Tapped(System.Object sender, System.EventArgs e)
        {

        }
    }
}
