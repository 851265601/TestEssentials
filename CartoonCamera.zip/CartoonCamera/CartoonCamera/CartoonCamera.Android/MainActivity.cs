﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.OS;
using Google.Android.Material.Snackbar;
using Android.Content;
using Android.Views;

namespace CartoonCamera.Droid
{
    [Activity(Label = "CartoonCamera", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize )]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        public static string myPath = "";
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);
            LoadApplication(new App());

           // myPath= Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures).ToString();

            if (!Android.OS.Environment.IsExternalStorageManager)
            {
                Snackbar.Make(FindViewById(Android.Resource.Id.Content), "Permission needed!", Snackbar.LengthIndefinite)
                        .SetAction("Settings", new MyOnClickListener(this)).Show();
            }
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    internal class MyOnClickListener : Java.Lang.Object, View.IOnClickListener
    {
        private MainActivity mainActivity;
        public MyOnClickListener()
        {
        }
        public MyOnClickListener(MainActivity mainActivity)
        {
            this.mainActivity = mainActivity;
        }
        public void OnClick(View v)
        {
            // throw new System.NotImplementedException();ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
            try
            {
                mainActivity.StartActivity(new Intent(
    Android.Provider.Settings.ActionManageAllFilesAccessPermission,
    Android.Net.Uri.Parse("package:" + Android.App.Application.Context.PackageName)));

            }
            catch (Exception ex)
            {
                Intent intent = new Intent();
                intent.SetAction(Android.Provider.Settings.ActionManageAllFilesAccessPermission);
                mainActivity.StartActivity(intent);
            }
        }
    }
}