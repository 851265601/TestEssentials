﻿using Android.App;
using Android.Content;
using Android.Media;
using Android.Net;
using Android.OS;
using Android.Provider;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using CartoonCamera.Droid;
using Java.IO;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;

[assembly: Dependency(typeof(GetPathService))]

namespace CartoonCamera.Droid
{
    public class GetPathService : IGetpath
    {
        public string getGellyPath()
        {
            return Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures).AbsolutePath;

        }

        public void fileUpdate(string filePath)
        {
            Context context = Android.App.Application.Context;
            // MediaStore.Images.Media.InsertImage();
          //  Intent mediaScanIntent = new Intent(Intent.ActionMediaScannerScanFile);
            //File f = new File(mCurrentPhotoPath);

            File file = new File(filePath);
            MediaScannerConnection.ScanFile(context,
                                new string[] { file.ToString() },
                                null, null);


     //       Uri contentUri = Uri.FromFile(file);
           // mediaScanIntent.SetData(contentUri);
          //  context.SendBroadcast(mediaScanIntent);
        }
    }
}