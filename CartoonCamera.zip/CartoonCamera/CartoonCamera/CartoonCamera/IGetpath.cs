﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CartoonCamera
{
   public interface IGetpath
    {
        string getGellyPath();

        void fileUpdate(string filePath);
    }
}
