﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App76
{
    public class Contact
    {
        public string Name { get; set; }

        public DateTime CreateTime { get; set; }
        public int PhoneNumber { get; set; }
    }
}
