﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace App76
{
    public  class MyViewModel: BaseViewModel
    {
        private bool _IsBusy;
        public bool IsBusy
        {
            get { return _IsBusy; }
            set { SetProperty(ref _IsBusy, value); }
        }
        // public ICommand TestCommand { protected set; get; }

        public ObservableCollection<Contact> Contacts { get; set; }
        public ObservableCollection<Contact> SelectItems { get; set; }
        public MyViewModel()
        {
            Contacts = new ObservableCollection<Contact>();
            SelectItems = new ObservableCollection<Contact>();
            Contacts.Add(new Contact() { Name="contact1", PhoneNumber=12356677, CreateTime=new DateTime(2015,1,6) });
            Contacts.Add(new Contact() { Name = "contact2", PhoneNumber = 12444677, CreateTime = new DateTime(2011, 10, 1) });
            Contacts.Add(new Contact() { Name = "contact3", PhoneNumber = 2366677, CreateTime = new DateTime(2012, 2, 7) });
            Contacts.Add(new Contact() { Name = "contact4", PhoneNumber = 200356677, CreateTime = new DateTime(2014, 12, 6) });
            Contacts.Add(new Contact() { Name = "contact5", PhoneNumber = 1230056677, CreateTime = new DateTime(2021, 1, 6) });
            List<Contact> newSort= Contacts.OrderByDescending(x => x.CreateTime).ToList<Contact>();
            Contacts.Clear();
            foreach (Contact item in newSort)
            {
                Contacts.Add(item);
            }
           
            //TestCommand = new Command(async (key) =>
            //{

            //    IsBusy = true;
            //    CommitChanges(); //takes aprox. 3 seconds
            //  //  IsBusy = false;
            //});


        }

        private async void CommitChanges()
        {
           
            await Task.Delay(3000);

            IsBusy = false;
        }
    }

    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(
               [CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(
                    this, new PropertyChangedEventArgs(propertyName));
        }

        protected void SetProperty<T>(ref T backingField,
              T value,
              [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(
                         backingField, value)) return;
            backingField = value;
            OnPropertyChanged(propertyName);
        }
    }
}
