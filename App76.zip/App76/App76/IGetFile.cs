﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App76
{
    public interface IGetFile
    {
        string ReadFile();
    }
}
