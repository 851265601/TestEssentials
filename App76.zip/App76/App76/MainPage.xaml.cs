﻿using SkiaSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace App76
{
    public partial class MainPage : ContentPage
    {
        MyViewModel myViewModel;
        public MainPage()
        {
            InitializeComponent();
            myViewModel = new MyViewModel();
            this.BindingContext = myViewModel;
        }

     

        private void CollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            List<Contact> contacts= e.CurrentSelection as List<Contact>;
       
            
        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            

            var locales = await TextToSpeech.GetLocalesAsync();

            // Grab the first locale
            var locale = locales.ElementAt<Locale>(37);
            var settings = new SpeechOptions()
            {
                Volume = .75f,
                Pitch = 1.0f,
                Locale = locale
            };

            await TextToSpeech.SpeakAsync("百度一下", settings);
        
        }
    }
}
