﻿using App76.iOS;
using Foundation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UIKit;
using Xamarin.Forms;

[assembly: Dependency(typeof(GetFile))]
namespace App76.iOS
{
    public class GetFile : IGetFile
    {
        public static string Path;
        public string ReadFile()
        {
            // thtow new NotImplementedException(); public.plain-text
            NSUrl url = new NSUrl("public.plain-text");
            UIDocument uIDocument = new UIDocument(url);

            string[] strs = { "public.image","public.text"};

            UIDocumentPickerViewController controller = new UIDocumentPickerViewController(strs, UIDocumentPickerMode.Open);
            controller.Delegate = new PickerClass();
         //   UIApplication.SharedApplication.Windows[0].RootViewController.PresentedViewController=controller;

            return Path;
        }
    }

    internal class PickerClass : UIDocumentPickerDelegate, IUIDocumentInteractionControllerDelegate
    {
        public override void DidPickDocument(UIDocumentPickerViewController controller, NSUrl url)
        {
            GetFile.Path = url.AbsoluteString;
           // throw new NotImplementedException();
        }
    }
}