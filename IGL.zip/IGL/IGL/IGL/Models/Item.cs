﻿using System;

namespace IGL.Models
{
    public class Item
    {
        public string Id { get; set; }
        public int ItemNo { get; set; }

        public string Text { get; set; }
        public string Description { get; set; }
    }
}