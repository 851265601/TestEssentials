﻿namespace IGL.Models
{
    public class ItemDets
    {
        public string DetId { get; set; }

        public string DetText { get; set; }
        public string DetDesc { get; set; }

    }


}